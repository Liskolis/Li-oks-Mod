package pl.lisoks.mod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class LisoksMod implements ClientModInitializer {
    public static LisoksConfig CONFIG;
    private static KeyBinding openMenu;
    @Override public void onInitializeClient() {
        CONFIG = LisoksConfig.load();
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.lisoksmod.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_L, KeyBinding.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                if (client.currentScreen instanceof LisoksScreen) client.setScreen(null);
                else if (client.currentScreen == null) client.setScreen(new LisoksScreen());
            }
        });
    }
}
