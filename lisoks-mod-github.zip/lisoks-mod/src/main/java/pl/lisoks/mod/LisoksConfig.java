package pl.lisoks.mod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class LisoksConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("lisoks-mod.json");
    public String style = "KRZYZYK";
    public String color = "#FF8800";
    public boolean enabled = true;
    public boolean top = true, bottom = true, left = true, right = true, dot = false;
    public int length = 6, thickness = 2, gap = 3, dotSize = 2;

    public static LisoksConfig load() {
        try {
            if (Files.exists(FILE)) {
                LisoksConfig c = GSON.fromJson(Files.readString(FILE), LisoksConfig.class);
                if (c != null) return c;
            }
        } catch (Exception ignored) { }
        LisoksConfig c = new LisoksConfig(); c.save(); return c;
    }
    public void save() {
        try { Files.createDirectories(FILE.getParent()); Files.writeString(FILE, GSON.toJson(this)); }
        catch (IOException e) { System.err.println("[Liśoks Mod] Nie udało się zapisać ustawień: " + e.getMessage()); }
    }
    public int colorInt() {
        try { return 0xFF000000 | Integer.parseInt(color.replace("#", ""), 16); }
        catch (Exception e) { return 0xFFFF8800; }
    }
}
