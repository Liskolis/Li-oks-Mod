package pl.lisoks.mod.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.MinecraftClient;
import pl.lisoks.mod.LisoksMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void lisoks$replaceCrosshair(DrawContext context, CallbackInfo ci) {
        var c = LisoksMod.CONFIG;
        if (c == null || !c.enabled) return;
        ci.cancel();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.getPerspective().isFirstPerson() && mc.player != null && !mc.options.hudHidden) {
            int x = mc.getWindow().getScaledWidth() / 2, y = mc.getWindow().getScaledHeight() / 2;
            int col = c.colorInt(), len = Math.max(1, c.length), thick = Math.max(1, c.thickness), gap = Math.max(0, c.gap);
            if (c.style.equals("KROPKA")) { context.fill(x-c.dotSize/2, y-c.dotSize/2, x+(c.dotSize+1)/2, y+(c.dotSize+1)/2, col); return; }
            if (c.style.equals("OKRAG")) {
                for (int i=0;i<24;i++) { double a=i*Math.PI/12; int px=x+(int)Math.round(Math.cos(a)*6), py=y+(int)Math.round(Math.sin(a)*6); context.fill(px,py,px+thick,py+thick,col); }
                return;
            }
            if (c.style.equals("RAMKA")) {
                context.fill(x-gap-len,y-gap-len,x-gap,y-gap-len+thick,col); context.fill(x+gap,y-gap-len,x+gap+len,y-gap-len+thick,col);
                context.fill(x-gap-len,y+gap+len-thick,x-gap,y+gap+len,col); context.fill(x+gap,y+gap+len-thick,x+gap+len,y+gap+len,col);
                context.fill(x-gap-len,y-gap-len,x-gap-len+thick,y-gap,col); context.fill(x+gap+len-thick,y-gap-len,x+gap+len,y-gap,col);
                context.fill(x-gap-len,y+gap,x-gap-len+thick,y+gap+len,col); context.fill(x+gap+len-thick,y+gap,x+gap+len,y+gap+len,col); return;
            }
            if (c.top) context.fill(x-thick/2,y-gap-len,x+(thick+1)/2,y-gap,col);
            if (c.bottom) context.fill(x-thick/2,y+gap,x+(thick+1)/2,y+gap+len,col);
            if (c.left) context.fill(x-gap-len,y-thick/2,x-gap,y+(thick+1)/2,col);
            if (c.right) context.fill(x+gap,y-thick/2,x+gap+len,y+(thick+1)/2,col);
            if (c.dot) context.fill(x-c.dotSize/2,y-c.dotSize/2,x+(c.dotSize+1)/2,y+(c.dotSize+1)/2,col);
        }
    }
}
