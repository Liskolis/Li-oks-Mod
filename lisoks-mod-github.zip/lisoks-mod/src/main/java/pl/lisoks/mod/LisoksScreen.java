package pl.lisoks.mod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import java.util.function.IntConsumer;

public class LisoksScreen extends Screen {
    private final LisoksConfig c = LisoksMod.CONFIG;
    private int page = 0;
    public LisoksScreen() { super(Text.literal("Liśoks Mod")); }
    @Override protected void init() { rebuild(); }
    private void rebuild() {
        clearChildren(); int cx=width/2, y=height/2-76;
        addDrawableChild(ButtonWidget.builder(Text.literal("Celownik"), b->{page=0;rebuild();}).dimensions(cx-190,y,90,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Kolor"), b->{page=1;rebuild();}).dimensions(cx-95,y,90,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Elementy"), b->{page=2;rebuild();}).dimensions(cx,y,90,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Rozmiar"), b->{page=3;rebuild();}).dimensions(cx+95,y,90,20).build());
        int yy=y+32;
        if(page==0) {
            String[] styles={"KRZYZYK","KROPKA","DUZY","RAMKA","KRESKI","OKRAG","WLASNY"};
            for(int i=0;i<styles.length;i++){ final String s=styles[i]; addDrawableChild(ButtonWidget.builder(Text.literal(label(s)),b->{c.style=s.equals("DUZY")?"KRZYZYK":s.equals("KRESKI")?"KRZYZYK":s;c.length=s.equals("DUZY")?10:c.length;c.save();rebuild();}).dimensions(cx-150+(i%2)*155,yy+(i/2)*25,145,20).build()); }
            addDrawableChild(ButtonWidget.builder(Text.literal(c.enabled?"Celownik: WŁĄCZONY":"Celownik: WYŁĄCZONY"),b->{c.enabled=!c.enabled;c.save();rebuild();}).dimensions(cx-150,yy+100,145,20).build());
        } else if(page==1) {
            String[][] colors={{"Biały","#FFFFFF"},{"Czerwony","#FF3333"},{"Zielony","#33FF66"},{"Niebieski","#3399FF"},{"Pomarańczowy","#FF8800"}};
            for(int i=0;i<colors.length;i++){final String hex=colors[i][1];addDrawableChild(ButtonWidget.builder(Text.literal(colors[i][0]),b->{c.color=hex;c.save();rebuild();}).dimensions(cx-145+(i%2)*150,yy+(i/2)*27,140,21).build());}
            addDrawableChild(ButtonWidget.builder(Text.literal("Własny HEX: " + c.color),b->{String[] opts={"#FF8800","#00FFFF","#FF00FF","#FFFFFF","#AAFF00"};int idx=0;for(int i=0;i<opts.length;i++)if(opts[i].equalsIgnoreCase(c.color))idx=i;c.color=opts[(idx+1)%opts.length];c.save();rebuild();}).dimensions(cx-145,yy+85,285,22).build());
        } else if(page==2) {
            addDrawableChild(toggle("Górna kreska",()->c.top,v->c.top=v,cx-150,yy));
            addDrawableChild(toggle("Dolna kreska",()->c.bottom,v->c.bottom=v,cx+5,yy));
            addDrawableChild(toggle("Lewa kreska",()->c.left,v->c.left=v,cx-150,yy+27));
            addDrawableChild(toggle("Prawa kreska",()->c.right,v->c.right=v,cx+5,yy+27));
            addDrawableChild(toggle("Środkowa kropka",()->c.dot,v->c.dot=v,cx-150,yy+54));
        } else {
            addDrawableChild(slider("Długość",c.length,1,20,v->c.length=v,cx-150,yy));
            addDrawableChild(slider("Grubość",c.thickness,1,8,v->c.thickness=v,cx-150,yy+28));
            addDrawableChild(slider("Odstęp",c.gap,0,15,v->c.gap=v,cx-150,yy+56));
            addDrawableChild(slider("Rozmiar kropki",c.dotSize,1,8,v->c.dotSize=v,cx-150,yy+84));
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Przywróć domyślne"),b->{c.enabled=true;c.style="KRZYZYK";c.color="#FF8800";c.length=6;c.thickness=2;c.gap=3;c.dotSize=2;c.top=c.bottom=c.left=c.right=true;c.dot=false;c.save();rebuild();}).dimensions(cx-150,height/2+75,145,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Zastosuj"),b->{c.save();}).dimensions(cx+5,height/2+75,70,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Zamknij"),b->{c.save();close();}).dimensions(cx+80,height/2+75,70,20).build());
    }
    private String label(String s){return switch(s){case "KRZYZYK"->"Klasyczny krzyżyk";case "KROPKA"->"Sama kropka";case "DUZY"->"Duży krzyżyk";case "RAMKA"->"Ramka";case "KRESKI"->"Krótkie kreski";case "OKRAG"->"Okrąg";default->"Własny";};}
    private ButtonWidget toggle(String name, java.util.function.BooleanSupplier get, java.util.function.Consumer<Boolean> set,int x,int y){return ButtonWidget.builder(Text.literal(name+": "+(get.getAsBoolean()?"TAK":"NIE")),b->{set.accept(!get.getAsBoolean());c.save();rebuild();}).dimensions(x,y,145,20).build();}
    private SliderWidget slider(String name,int value,int min,int max,IntConsumer setter,int x,int y){return new SliderWidget(x,y,300,20,Text.literal(name+": "+value),(double)(value-min)/(max-min)){protected void updateMessage(){setMessage(Text.literal(name+": "+(min+(int)Math.round(value*(max-min)))));}protected void applyValue(){int v=min+(int)Math.round(value*(max-min));setter.accept(v);c.save();}};}
    @Override public void render(DrawContext context,int mouseX,int mouseY,float delta){context.fill(0,0,width,height,0xB9000000);int w=410,h=height/2+135,x=(width-w)/2,y=(height-h)/2;context.fill(x,y,x+w,y+h,0xFF17191F);context.fill(x,y,x+w,y+3,0xFFFF8800);context.drawCenteredTextWithShadow(textRenderer,"Liśoks Mod",width/2,y+12,0xFFFF8800);context.drawCenteredTextWithShadow(textRenderer,"Personalizacja celownika",width/2,y+27,0xFFCCCCCC);super.render(context,mouseX,mouseY,delta);}
    @Override public boolean shouldPause(){return false;}
    @Override public void close(){c.save();super.close();}
}
