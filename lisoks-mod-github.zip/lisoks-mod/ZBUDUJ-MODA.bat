@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo         LISOKS MOD - BUDOWANIE JAR
echo ============================================
echo.
where java >nul 2>nul
if errorlevel 1 (
  echo BLAD: Nie znaleziono Javy. Zainstaluj JDK 21 i uruchom ten plik ponownie.
  echo Pobierz JDK 21, a po instalacji zamknij i otworz to okno ponownie.
  pause
  exit /b 1
)
set "GRADLE_VERSION=9.2.1"
set "TOOLS_DIR=%~dp0.tools"
set "GRADLE_HOME=%TOOLS_DIR%\gradle-%GRADLE_VERSION%"
set "GRADLE_EXE=%GRADLE_HOME%\bin\gradle.bat"
if not exist "%GRADLE_EXE%" (
  echo Pobieram Gradle %GRADLE_VERSION%. To moze zajac kilka minut i wymaga internetu.
  if not exist "%TOOLS_DIR%" mkdir "%TOOLS_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $zip=Join-Path '%TOOLS_DIR%' 'gradle.zip'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile $zip; Expand-Archive -LiteralPath $zip -DestinationPath '%TOOLS_DIR%' -Force; Remove-Item $zip -Force"
  if errorlevel 1 (
    echo BLAD: Nie udalo sie pobrac Gradle. Sprawdz internet i sprobuj ponownie.
    pause
    exit /b 1
  )
)
echo.
echo Buduje moda. Przy pierwszym uruchomieniu Gradle pobierze zaleznosci Minecraft/Fabric.
echo Nie zamykaj tego okna.
echo.
call "%GRADLE_EXE%" --no-daemon clean build
if errorlevel 1 (
  echo.
  echo BUDOWANIE NIE POWIODLO SIE. Skopiuj caly komunikat bledu i wyslij go w ChatGPT.
  pause
  exit /b 1
)
echo.
echo GOTOWE. Plik moda powinien byc w:
echo %~dp0build\libs\lisoks-mod-1.0.0.jar
echo.
echo Skopiuj ten plik do folderu .minecraft\mods.
pause
