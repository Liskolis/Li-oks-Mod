# Liśoks Mod — Minecraft Java 1.21.11 (Fabric)

Projekt źródłowy moda klienckiego personalizującego celownik. Wymaga JDK 21 oraz połączenia z internetem przy pierwszym budowaniu, aby Gradle pobrał zależności.

## Budowanie
1. Zainstaluj JDK 21 i IntelliJ IDEA Community.
2. Otwórz folder projektu `lisoks-mod` w IntelliJ IDEA jako projekt Gradle.
3. Poczekaj na pobranie zależności.
4. W terminalu w folderze projektu uruchom `gradle build` (na Windows, gdy masz wrapper Gradle, użyj `gradlew.bat build`).
5. Plik JAR powinien powstać w `build/libs/`.

## Instalacja
Zainstaluj Fabric Loader dla Minecraft 1.21.11 oraz Fabric API zgodne z 1.21.11. Skopiuj zbudowany `lisoks-mod-1.0.0.jar` do `%appdata%\.minecraft\mods` i uruchom profil Fabric.

Ustawienia zapisują się w `.minecraft/config/lisoks-mod.json`. Menu otwiera klawisz L.

## Ważne
Ten pakiet jest projektem źródłowym, nie skompilowanym plikiem JAR. W środowisku, w którym przygotowano pliki, nie ma Gradle ani dostępu do sieci, więc nie można tu pobrać zależności ani potwierdzić kompilacji. Po pierwszym otwarciu w IntelliJ Gradle pobierze je z repozytoriów, a ewentualny błąd kompilacji należy sprawdzić w komunikacie Gradle.

## Najprostsze budowanie na Windows

1. Upewnij się, że masz zainstalowane JDK 21.
2. Kliknij dwukrotnie `ZBUDUJ-MODA.bat` i poczekaj na koniec. Pierwsze uruchomienie wymaga internetu i może pobierać sporo plików.
3. Jeśli zakończy się komunikatem `GOTOWE`, skopiuj `build\libs\lisoks-mod-1.0.0.jar` do folderu `.minecraft\mods`.
4. Użyj Minecraft Java 1.21.11 z Fabric Loader i Fabric API dla 1.21.11.

Jeśli skrypt zgłosi błąd, nie instaluj pliku z `build\libs`, jeśli go nie utworzył. Skopiuj komunikat błędu, żeby można było poprawić projekt.
